A01 — 102 finite source slots, converted asset package

IMPORT CLOCK: 30,000 FPS. This is a Blender compatibility timeline, not the
source frame rate. Importing changes the GLOBAL scene FPS. Physical take seconds
are unchanged: source review frame f maps to timeline frame f*1000+1 in Blender.
The source review convention is 30 FPS. Use an isolated scene or explicitly
validated clock normalization. Mixed-clock scenes, engine import/resampling and
native game playback equivalence are NOT certified. Do not silently retime.

Choose A01_slotNNN_BAKED_SOURCE_FINITE after import. The 102 slots include static
poses, a body-static slot000 with effect motion, and genuine short fragments;
they are not 102 uniquely named gameplay animations. Half-open source windows
are retained; the final source pose is held to each declared endpoint. No loops
or gameplay names have been invented.

The FBX contains 17 body joints, four rigid companion meshes/joints and four
animated billboard anchors in a deliberate flat-world delivery rig. Body skin
weights and inverse binds are preserved from the verified original GLB. Effect
anchors use explicit identity delivery binds with unchanged local geometry and
source-world motion. Geometric normals are a documented visual approximation;
only exact zero-area triangles were removed.

The atlas is embedded and supplied separately. Ordinary diffuse FBX materials
are approximations, not exact original shaders. A01_RUNTIME_COMPANION.json
contains all four original billboard strips, UVs, animated anchor names, the
analytic perspective-facing formula and authored blend/depth/cull settings.
Attach these to the actual runtime camera; do not treat anchors as rendered
billboards. The four ordinary rigid strips already exist in the FBX—do not
create duplicates. Game-level visibility/pass scheduling, dynamic materials,
hardware filtering and original floating-point execution remain unverified.

Validation: all 102 actions passed 17,956 deterministic source-key, extrema and
fitted-interval witnesses in unmodified Blender 4.3.2 at the stated timeline rate:
87,032,732 evaluated vertex comparisons; maximum position error 0.002316012 in
raw review units, against the unchanged 0.005 gate. Maximum effect matrix error
0.000199864, against 0.002. Exact source-model mathematics is an explicit binary64
reconstruction, not a claim of original hardware execution. Source animation
seconds, all curve ticks/values, geometry/binds/UVs and atlas were independently
checked. This public projection removes internal metadata only; it does not
alter animation or geometry. Engine resampling is a separate unverified step.

Reference-camera diagnostic images were inspected for body/attachment coherence
and atlas placement. Billboard preview is NOT an additive-render certification.
For the supplied GX_BM_BLEND contract, implement source-alpha plus destination
one (Cout = Csrc * Asrc + Cdst), depth test LEQUAL, depth writes disabled,
color writes enabled, framebuffer-alpha writes disabled, and each record's
explicit culling and remaining render-state settings. Verify the actual engine
camera, material pipeline and pass ordering separately. Do not use ordinary
alpha-over sprites as a substitute for this additive contract.

See NOTICE.txt before redistribution. No raw game archives, executable images,
private filesystem paths, internal proof files or credentials are bundled.
