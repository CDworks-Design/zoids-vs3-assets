A02 — 102 finite body-animation slots, converted asset package

IMPORT CLOCK: 30,000 FPS. Import changes the GLOBAL Blender scene FPS. This is a
compatibility timeline, not a claim about the native game's playback rate.
Physical take seconds are unchanged: review frame f maps to Blender frame
f*1000+1, using the 30-FPS review convention. Use an isolated scene or separately
validated clock normalization. Do not reset scene FPS alone or silently mix
other-rate animations. Engine importing/resampling is NOT certified.

Choose an action containing A02_SLOTNNN_TEXTURED_BAKED_FINITE. All 102 original
slot indices are present, including short fragments and poses; these are not
102 uniquely named gameplay animations. No gameplay names or loops were
invented. Source requests stop one sixteenth of a review frame before each
header endpoint, with an explicit small finite presentation hold to that endpoint.

This is a flat-world baked delivery rig, not the original controller hierarchy.
The six retained draw meshes preserve original source positions, single-influence
weights, raw binds and the three source PNG atlases (embedded and supplied beside
the FBX). Four ordinary diffuse materials approximate the source appearance.
Geometric normals are a documented approximation: 199 exact zero-area faces were
removed and 2,802 source-opposed face windings corrected without changing source
positions, weights or animation curves. Source-hidden helper boxes are omitted
based on verified default-hidden flags, not shape alone. Their runtime visibility,
node3 auxiliary effects, dynamic materials and original shader/pass behavior
remain unqualified. This package is not a full native-game render recreation.

Own A02 constraint/expression math was reconstructed with explicit binary32 field
stores and host-binary64 matrices, not original hardware execution. Slot048's
slightly affine epsilon-normalized head basis is retained through its narrowly
verified child propagation, rather than silently exact-normalized. Its baked
representation passed additional dense alignment witnesses. Fixed Euler orders
are shared across every action; original fitted key timelines are retained.

Validation: all 102 actions passed 102,330 deterministic source-key,
adjacent-binary32, dense-grid, interval/random and explicit-hold queries in
unmodified Blender 4.3.2: 534,674,250 evaluated vertex comparisons.
Maximum position error was 0.00286301847375 in raw review units (gate 0.005).
Maximum effective review-frame error was 1.44042968486e-05. Geometric normals
were finite/unit. Front/rear, formerly importer-held motion and the slot048
alignment pose were visually inspected for coherence and atlas placement.
See VALIDATION.json for per-action counts and durations. The public projection
removes internal non-runtime properties only: geometry, binds, weights, UVs,
textures, standard transforms, clock values and all animation payloads retain
an exact critical-content digest. Original hardware, source custom normals,
seamless gameplay loops and Unreal/other-engine equivalence are not certified.

See NOTICE.txt before redistribution. No raw game archive, executable image,
private filesystem paths, Library identifiers, credentials or internal proof
files are included. Preview images are diagnostic views, not shader equivalence.
