A05 — 102 finite body-animation slots, converted asset package

IMPORT CLOCK: 30,000 FPS. Import changes the GLOBAL Blender scene FPS.
Physical take seconds are unchanged: review frame f maps to Blender frame
f*1000+1 under the 30-FPS review convention. Use an isolated scene or separately
validated clock normalization. Do not reset scene FPS alone or silently mix
other-rate animations. This is not the native game's playback-rate claim.
Engine importing, resampling and Unreal equivalence are NOT certified.

Choose an action containing A05_SLOTNNN_BAKED_SOURCE_FINITE. Original slot
indices 000–101 are retained, including short fragments and poses; these are not
102 uniquely named gameplay animations. No gameplay names or loops were invented.
Fresh source requests stop at the largest admitted binary32 request below each
header endpoint. The tiny remaining interval is an explicit presentation hold;
the source endpoint itself and seamless looping are not certified.

This flat-world baked rig is not the original controller hierarchy. Four retained
textured draw parts preserve source positions, raw inverse binds, UVs and the
original PNG atlas (embedded and supplied beside the FBX). Source-effective
weights follow the verified first-weight rule: four raw two-entry palettes each
contain two unit weights, but the source selects the first; all 26 effective
palettes are single-joint. The gallery's 32 differing vertex weights were NOT
substituted. Original source/controller and host-binary64 matrix behavior were
reconstructed with explicit binary32 field stores, not native hardware execution.
Fixed model-wide Euler orders are shared across all 102 actions.

Geometric normals are a documented compatibility approximation: 328 exact
zero-area faces were removed, 5,505 source-opposed windings reversed and 2 aligned
faces retained, leaving 5,507 triangles. Positions, effective weights, raw binds,
UV mapping and animation payloads are preserved. Fifteen default-hidden source
parts are omitted using verified flags; their runtime visibility remains
unqualified. Diffuse materials approximate appearance; original shader passes,
dynamic materials and source custom-normal behavior are not certified.

All 102 actions passed 113,135 deterministic key, adjacent-normal-binary32,
dense-grid, interval/random and explicit-hold queries in unmodified Blender
4.3.2: 1,234,189,715 evaluated vertex comparisons. Maximum position
error was 0.00459733369384 review units (fixed gate 0.005). Maximum effective review
frame error was 1.56250000032e-05. Geometric normals were finite/unit, atlas hash
and action ranges checked. Four targeted full-bank poses, including the worst
numerical witness in slot 066, were inspected with +Y display framing and no
denoising; prefix 000–003 also had a 12-pose inspection. These are bounded visual
checks, not source-shader equivalence. See VALIDATION.json for per-slot durations.

The public projection removes internal non-runtime properties only. Geometry,
binds, effective weights, UVs, textures, standard transforms, clock values and
all animation payloads retain an exact critical-content digest. No raw game
archive, executable, private path, Library identifier, credentials or internal
proof files are included. See NOTICE.txt before redistribution.
