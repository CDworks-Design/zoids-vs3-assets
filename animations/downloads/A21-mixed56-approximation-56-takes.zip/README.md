# A21 animation asset — mixed56-approximation

56 take record(s), provided as a Blender-compatible FBX and its exact texture atlas.

## Use
Import the FBX into Blender. The atlas is embedded and also supplied beside the FBX under the referenced basename. Preserve both files together when using another importer. Take names are listed below.

## Validation and limits
Tested with Blender 4.3.2, including sampled positions and durations. This is not a native-game playback, arbitrary-time interpolation, seamless-loop, Unreal, or uniform cross-importer certification. Source frame-rate interpretation is unverified; display timing is a presentation assumption. Endpoint holds and any static representatives are intentional.

Compatibility processing corrected visibility metadata, removed exact zero-area faces, normalized winding and UV-corner order where needed, and used geometric normals instead of source-authored custom normals. Shading is approximate. These packaged FBX bytes are unchanged from the checked compatibility exports; no additional re-export or resampling was performed for publication.

The standard package contains 55 checked take records. The optional mixed-profile package contains those same 55 plus slot006; these packages overlap and must not be summed.

Slot006 is named A21_SLOT006_FIXED120HZ_APPROXIMATION. It is a fixed-120-Hz approximation, not an arbitrary-time or native-fidelity qualification. Nominal 30/60/120-Hz source-position error was approximately 6.072e-6/6.072e-6/6.195e-6; tested off-grid maximum error was 0.185783 (about 0.91% of visible model dimension).

## Take records
- `A21_SLOT001_TEXTURED_BAKED_FINITE`
- `A21_SLOT013_TEXTURED_BAKED_FINITE`
- `A21_SLOT000_TEXTURED_BAKED_FINITE`
- `A21_SLOT014_TEXTURED_BAKED_FINITE`
- `A21_SLOT015_TEXTURED_BAKED_FINITE`
- `A21_SLOT016_TEXTURED_BAKED_FINITE`
- `A21_SLOT071_TEXTURED_BAKED_FINITE`
- `A21_SLOT072_TEXTURED_BAKED_FINITE`
- `A21_SLOT076_TEXTURED_BAKED_FINITE`
- `A21_SLOT081_TEXTURED_BAKED_FINITE`
- `A21_SLOT018_TEXTURED_BAKED_FINITE`
- `A21_SLOT019_TEXTURED_BAKED_FINITE`
- `A21_SLOT022_TEXTURED_BAKED_FINITE`
- `A21_SLOT023_TEXTURED_BAKED_FINITE`
- `A21_SLOT026_TEXTURED_BAKED_FINITE`
- `A21_SLOT027_TEXTURED_BAKED_FINITE`
- `A21_SLOT030_TEXTURED_BAKED_FINITE`
- `A21_SLOT031_TEXTURED_BAKED_FINITE`
- `A21_SLOT034_TEXTURED_BAKED_FINITE`
- `A21_SLOT035_TEXTURED_BAKED_FINITE`
- `A21_SLOT038_TEXTURED_BAKED_FINITE`
- `A21_SLOT039_TEXTURED_BAKED_FINITE`
- `A21_SLOT041_TEXTURED_BAKED_FINITE`
- `A21_SLOT042_TEXTURED_BAKED_FINITE`
- `A21_SLOT059_TEXTURED_BAKED_FINITE`
- `A21_SLOT058_TEXTURED_BAKED_FINITE`
- `A21_SLOT050_TEXTURED_BAKED_FINITE`
- `A21_SLOT051_TEXTURED_BAKED_FINITE`
- `A21_SLOT052_TEXTURED_BAKED_FINITE`
- `A21_SLOT053_TEXTURED_BAKED_FINITE`
- `A21_SLOT054_TEXTURED_BAKED_FINITE`
- `A21_SLOT055_TEXTURED_BAKED_FINITE`
- `A21_SLOT056_TEXTURED_BAKED_FINITE`
- `A21_SLOT060_TEXTURED_BAKED_FINITE`
- `A21_SLOT063_TEXTURED_BAKED_FINITE`
- `A21_SLOT064_TEXTURED_BAKED_FINITE`
- `A21_SLOT066_TEXTURED_BAKED_FINITE`
- `A21_SLOT078_TEXTURED_BAKED_FINITE`
- `A21_SLOT017_TEXTURED_BAKED_FINITE`
- `A21_SLOT020_TEXTURED_BAKED_FINITE`
- `A21_SLOT021_TEXTURED_BAKED_FINITE`
- `A21_SLOT024_TEXTURED_BAKED_FINITE`
- `A21_SLOT025_TEXTURED_BAKED_FINITE`
- `A21_SLOT028_TEXTURED_BAKED_FINITE`
- `A21_SLOT029_TEXTURED_BAKED_FINITE`
- `A21_SLOT032_TEXTURED_BAKED_FINITE`
- `A21_SLOT033_TEXTURED_BAKED_FINITE`
- `A21_SLOT036_TEXTURED_BAKED_FINITE`
- `A21_SLOT037_TEXTURED_BAKED_FINITE`
- `A21_SLOT040_TEXTURED_BAKED_FINITE`
- `A21_SLOT061_TEXTURED_BAKED_FINITE`
- `A21_SLOT065_TEXTURED_BAKED_FINITE`
- `A21_SLOT043_TEXTURED_BAKED_FINITE`
- `A21_SLOT044_TEXTURED_BAKED_FINITE`
- `A21_SLOT045_TEXTURED_BAKED_FINITE`
- `A21_SLOT006_FIXED120HZ_APPROXIMATION`

## Rights
See ASSET_RIGHTS.md. These are derived original-game assets; availability is not an unrestricted, commercial, open-source, or blanket redistribution license. No game executable, source code, private research, or recovery material is included.
