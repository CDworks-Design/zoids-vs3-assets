# A25 animation asset — blender-compat

1 take record(s), provided as a Blender-compatible FBX and its exact texture atlas.

## Use
Import the FBX into Blender. The atlas is embedded and also supplied beside the FBX under the referenced basename. Preserve both files together when using another importer. Take names are listed below.

## Validation and limits
Tested with Blender 4.3.2, including sampled positions and durations. This is not a native-game playback, arbitrary-time interpolation, seamless-loop, Unreal, or uniform cross-importer certification. Source frame-rate interpretation is unverified; display timing is a presentation assumption. Endpoint holds and any static representatives are intentional.

Compatibility processing corrected visibility metadata, removed exact zero-area faces, normalized winding and UV-corner order where needed, and used geometric normals instead of source-authored custom normals. Shading is approximate. These packaged FBX bytes are unchanged from the checked compatibility exports; no additional re-export or resampling was performed for publication.

Slot001 uses the accepted default-visible model, source-duration 119 and a 1/16-source-frame endpoint hold. The mixed-joint bridge connection is retained.

## Take records
- `A25_SLOT001_TEXTURED_BAKED_FINITE`

## Rights
See ASSET_RIGHTS.md. These are derived original-game assets; availability is not an unrestricted, commercial, open-source, or blanket redistribution license. No game executable, source code, private research, or recovery material is included.
