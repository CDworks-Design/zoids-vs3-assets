# B26 animation asset — blender-compat

20 take record(s), provided as a Blender-compatible FBX and its exact texture atlas.

## Use
Import the FBX into Blender. The atlas is embedded and also supplied beside the FBX under the referenced basename. Preserve both files together when using another importer. Take names are listed below.

## Validation and limits
Tested with Blender 4.3.2, including sampled positions and durations. This is not a native-game playback, arbitrary-time interpolation, seamless-loop, Unreal, or uniform cross-importer certification. Source frame-rate interpretation is unverified; display timing is a presentation assumption. Endpoint holds and any static representatives are intentional.

Compatibility processing corrected visibility metadata, removed exact zero-area faces, normalized winding and UV-corner order where needed, and used geometric normals instead of source-authored custom normals. Shading is approximate. These packaged FBX bytes are unchanged from the checked compatibility exports; no additional re-export or resampling was performed for publication.

20 take records comprise 17 moving takes and static representatives 075, 081, and 097. Slot006 retains the explicit name B26_SLOT006_TARGETED_PREVIEW_NOT_STRICT_QUALIFIED; it is a targeted preview, not a strict qualification. Endpoint holds vary: inherited 001/006 use 0.25 source frame; newer takes generally use 1/16 source frame.

## Take records
- `B26_SLOT001_EXISTING_KEYS_FIVE_ZYX_CONTROL`
- `B26_SLOT006_TARGETED_PREVIEW_NOT_STRICT_QUALIFIED`
- `B26_SLOT013_PRACTICAL`
- `B26_SLOT017_PRACTICAL`
- `B26_SLOT077_PRACTICAL`
- `B26_SLOT000_PRACTICAL`
- `B26_SLOT004_PRACTICAL`
- `B26_SLOT008_PRACTICAL`
- `B26_SLOT075_PRACTICAL`
- `B26_SLOT081_PRACTICAL`
- `B26_SLOT097_PRACTICAL`
- `B26_SLOT021_PRACTICAL`
- `B26_SLOT025_PRACTICAL`
- `B26_SLOT029_PRACTICAL`
- `B26_SLOT037_PRACTICAL`
- `B26_SLOT058_PRACTICAL`
- `B26_SLOT043_PRACTICAL`
- `B26_SLOT070_PRACTICAL`
- `B26_SLOT005_PRACTICAL`
- `B26_SLOT044_PRACTICAL`

## Rights
See ASSET_RIGHTS.md. These are derived original-game assets; availability is not an unrestricted, commercial, open-source, or blanket redistribution license. No game executable, source code, private research, or recovery material is included.
