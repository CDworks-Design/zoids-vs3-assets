# B33 animation asset — Blender compatibility edition

20 take records in a Blender-compatible FBX, with its exact texture atlas.

## Use
Import the FBX into Blender. The exact atlas is embedded in the FBX. A separate copy is available as b33_tex_014560_cmpr.png beside this ZIP in the downloads directory. For importers that need external textures, download it and place it beside the extracted FBX. The separate PNG is not included inside this ZIP.

## Model and validation
This is the 12-part default-visible model. It is not the separate full 18-part model variant. The checked compatibility export was tested with Blender 4.3.2 across 20 actions and 60 sampled poses; compared sampled positions were unchanged. This package preserves that checked FBX byte-for-byte, with no additional re-export or resampling.

## Limits
Take names containing NATIVE_STANDARD_WEIGHT describe the retained export names, not native-game playback fidelity or certification. Sampled validation does not certify arbitrary-time interpolation, uniform cross-importer behavior, Unreal support, or seamless loops. Source frame-rate interpretation is unverified; display timing is a presentation assumption. Endpoint holds are retained.

Compatibility processing corrected visibility metadata, removed exact zero-area faces, normalized winding and UV-corner order where needed, and used geometric normals instead of source-authored custom normals. Shading is approximate.

## Take records
- `B33_NATIVE_STANDARD_WEIGHT_slot001`
- `B33_NATIVE_STANDARD_WEIGHT_slot002`
- `B33_NATIVE_STANDARD_WEIGHT_slot004`
- `B33_NATIVE_STANDARD_WEIGHT_slot005`
- `B33_NATIVE_STANDARD_WEIGHT_slot006`
- `B33_NATIVE_STANDARD_WEIGHT_slot007`
- `B33_NATIVE_STANDARD_WEIGHT_slot010`
- `B33_NATIVE_STANDARD_WEIGHT_slot011`
- `B33_NATIVE_STANDARD_WEIGHT_slot014`
- `B33_NATIVE_STANDARD_WEIGHT_slot012`
- `B33_NATIVE_STANDARD_WEIGHT_slot013`
- `B33_NATIVE_STANDARD_WEIGHT_slot008`
- `B33_NATIVE_STANDARD_WEIGHT_slot009`
- `B33_NATIVE_STANDARD_WEIGHT_slot003`
- `B33_NATIVE_STANDARD_WEIGHT_slot000`
- `B33_NATIVE_STANDARD_WEIGHT_slot033`
- `B33_NATIVE_STANDARD_WEIGHT_slot043`
- `B33_NATIVE_STANDARD_WEIGHT_slot066`
- `B33_NATIVE_STANDARD_WEIGHT_slot067`
- `B33_NATIVE_STANDARD_WEIGHT_slot078`

## Rights
See ASSET_RIGHTS.md. These are derived original-game assets; availability is not an unrestricted, commercial, open-source, or blanket redistribution license. No game executable, source code, private research, or recovery material is included.
